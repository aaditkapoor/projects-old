//
//  ViewController.swift
//  iOSPractice
//
//  Created by Aadit Kapoor on 9/22/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var consoleOutput: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        inputTextField.delegate = self
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        print(inputTextField.text!)
    }

    


}

