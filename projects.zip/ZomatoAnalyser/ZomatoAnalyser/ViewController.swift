//
//  ViewController.swift
//  ZomatoAnalyser
//
//  Created by Aadit Kapoor on 6/17/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func searchAction(_ sender: UIButton) {
        // 
    }
}

