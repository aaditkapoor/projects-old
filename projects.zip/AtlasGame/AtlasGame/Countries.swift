//
//  Countries.swift
//  AtlasGame
//
//  Created by Aadit Kapoor on 6/6/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import Foundation


class Countries {
    var countries:[String] = [
    ]
}
