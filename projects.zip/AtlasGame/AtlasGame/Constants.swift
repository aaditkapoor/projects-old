//
//  Constants.swift
//  AtlasGame
//
//  Created by Aadit Kapoor on 6/6/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import Foundation

var baseURL = "https://atlasapi.herokuapp.com/"

enum Command:String {
    case load = "load"
    case move_forward = "move-forward"
    case displayData = "data"
    case start_game = "start-game"
}

func createUrl(what:String) -> String {
    return baseURL+what
}
