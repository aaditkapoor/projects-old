//
//  CountryThinker.swift
//  AtlasGame
//
//  Created by Aadit Kapoor on 6/7/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import Foundation


class CountryThinker {
    var data:Array<String> = []
    init(data:Array<String>) {
        self.data = data
    }
    
    func getRandom(data:Array<String>) -> String {
        let n = Int(arc4random_uniform(UInt32(UInt(data.count-1))) + 0)
        return data[n]
    }
    
    
    public func pickRandomCountry() -> String {
        return getRandom(data: self.data)
    }
    
    
    func validateEnteredCountry(beforeCountry:String,enteredCountry:String) -> String? {
        if enteredCountry.characters.first == beforeCountry.characters.last {
            return enteredCountry
        }
        
        else {
            return nil
        }
        
    }
    
    func getComputerSmartTurn(user:String) -> String{
        var c = pickRandomCountry()
        if user.characters.last == c.characters.first {
            return c
        }
        else {
            return getComputerSmartTurn(user: user)
        }
    }
}
