//
//  ShareViewController.swift
//  Share
//
//  Created by Aadit Kapoor on 10/6/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Social

class ShareViewController: SLComposeServiceViewController {
    
    override func isContentValid() -> Bool {
        // Do validation of contentText and/or NSExtensionContext attachments here
        
        return true
    }
    override func didSelectPost() {
        getURL { (url) in
            if (url != nil) {
                
                // Save To File Here.
                
            self.extensionContext!.completeRequest(returningItems: [], completionHandler: nil)
            }
            else {
                print("error")
            }

        }
    
    }
    
    
    /**
         A function to capture the url from the share link.
     */
    
    
    func getURL(gotURL: @escaping (URL?) -> ()) {
        
        if let item = extensionContext?.inputItems.first as? NSExtensionItem {
            if let itemprovider = item.attachments?.first as? NSItemProvider {
                if itemprovider.hasItemConformingToTypeIdentifier("public.url") {
                    itemprovider.loadItem(forTypeIdentifier: "public.url", options: nil, completionHandler: { (url, error) in
                        
                        
                        if let u = url as? URL {
                            gotURL(u)
                        }
                        else {
                            gotURL(nil)
                        }
                        
                    })
                }
            }
        }
    }
    
    override func configurationItems() -> [Any]! {
        // To add configuration options via table cells at the bottom of the sheet, return an array of SLComposeSheetConfigurationItem here.
        return []
    }
    
}
