//
//  GetText.swift
//  IWRIT
//
//  Created by Aadit Kapoor on 10/6/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import Foundation
