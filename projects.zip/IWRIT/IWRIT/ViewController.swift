//
//  ViewController.swift
//  IWRIT
//
//  Created by Aadit Kapoor on 10/6/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import BulletinBoard
import CoreML

class ViewController: UITableViewController {
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        
    }

    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        }


}

