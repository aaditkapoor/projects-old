//: Playground - noun: a place where people can play

import UIKit
import Kanna
