//
//  ViewController.swift
//  WebScraping
//
//  Created by Aadit Kapoor on 9/27/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Kanna
import SwiftSoup

class ViewController: UIViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    func tryToGetContent() {
        
        let a = "https://fmovies.to/film/the-social-network.7jq8/09x023"
        let url = URL(string: a)!
        
        var request = URLRequest(url: url)
        request.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36", forHTTPHeaderField: "User-Agent")
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            let html = String(data: data!, encoding: .utf8)
            print(html)
        }.resume()
      
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        tryToGetContent()
        
       
    }
}




