//
//  SaveDataForPersistance.swift
//  BlindLearningApp
//
//  Created by Aadit Kapoor on 5/27/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import Foundation

class SaveData{
    
    var content:String!
    
    init(data: String) {
        
        self.content = data
    }
    
    func save(lesson:String) {
        UserDefaults.standard.set(content, forKey: "content_\(lesson)")
    }
    
    func getContent(lesson: String) -> String {
        
        return UserDefaults.standard.object(forKey: "content_\(lesson)") as! String
    }
}

