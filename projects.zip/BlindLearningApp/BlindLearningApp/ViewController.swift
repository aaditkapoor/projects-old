//
//  ViewController.swift
//  BlindLearningApp
//
//  Created by Aadit Kapoor on 5/27/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Speech
import Alamofire


class ViewController: UIViewController {
    
    
    
    
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: message, message: nil, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default , handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                if authStatus == SFSpeechRecognizerAuthorizationStatus.authorized {
                    
                }
            }
        }
    }
    
    
}





