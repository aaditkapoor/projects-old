//
//  LessonFramework.swift
//  BlindLearningApp
//
//  Created by Aadit Kapoor on 5/27/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//


class Lesson {
    var content: String!
    var name: String!
    var lesson_score:Int = 0
    
    
    var lesson_questions:Dictionary<String,String>!
    
    init(name: String) {
        self.name = name
    }
    
    func addQuestion(data: Dictionary<String,String>) {
        self.lesson_questions = data
    }
    
    
    func addContent(content: String) {
        self.content = content
    }
    
    
    func displayLessonContent() -> String {
        return self.content
    }
    
    func speakLessonContent() {
        // Speaking Code
    }
    
    func lessonScoreUp() {
        self.lesson_score+=1
    }
    
    func wrapUpLesson() {
        print ("You scored \(self.lesson_score).")
    }
}
