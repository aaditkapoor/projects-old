//
//  LessonsViewController.swift
//  BlindLearningApp
//
//  Created by Aadit Kapoor on 5/27/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Alamofire
import Speech
// LessonViewController: Used to control all instances of user interaction with app.





class LessonsViewController: UIViewController {
    @IBOutlet weak var lessonOneStack: UIStackView!
    @IBOutlet weak var lessonFourStack: UIStackView!
    @IBOutlet weak var lessonTwoStack: UIStackView!
    @IBOutlet weak var lessonThreeStack: UIStackView!
    
    @IBOutlet weak var dataIndicatorLabel: UILabel!
    
    var lessonOneData:Lesson!
    var lessonTwoData:Lesson!
    var lessonThreeData:Lesson!
    var lessonFourData:Lesson!
    
    
    var d: Dictionary<String,String> = [:]
    
    
    
    enum QuestionPattern:String {
        case First = "Now I will ask a question!"
        case Second = "Another question for you!"
        case Third = "One More"
    }
    
    
    func disableControls() {
        lessonOneStack.isUserInteractionEnabled=false
    }
    
    // Speech
    let speechSynthesizer = AVSpeechSynthesizer()
    
    
    func showDescriptionForLesson(desc: String) {
        let alert = UIAlertController(title: "Description", message: desc, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Return", style: UIAlertActionStyle.default , handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: message, message: nil, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default , handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    
    
    func tryToGetContentDataFromServer() {
        
        let urlOne:String = "https://blindlearningapp.herokuapp.com/lessons?lesson_name=Math"
        let urlTwo:String = "https://blindlearningapp.herokuapp.com/lessons?lesson_name=Science"
        let urlThree:String = "https://blindlearningapp.herokuapp.com/lessons?lesson_name=History"
        let urlFour:String = "https://blindlearningapp.herokuapp.com/lessons?lesson_name=English"
        
        
        
        
        
        Alamofire.request(urlOne).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                // Lesson One
                let jsonObject = response.result.value as! NSDictionary
                self.lessonOneData.addContent(content: jsonObject.object(forKey: "content") as! String)
                
                
            }
            else {
                self.showAlert(message: "There is an error in retreiving the data.")
            }
        }
        
        
        // Lesson 2
        
        
        Alamofire.request(urlTwo).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                // Lesson One
                let jsonObject = response.result.value as! NSDictionary
                self.lessonTwoData.addContent(content: jsonObject.object(forKey: "content") as! String)
                
                
            }
            else {
                self.showAlert(message: "There is an error in retreiving the data.")
            }
        }
        
        
        Alamofire.request(urlThree).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                // Lesson three
                let jsonObject = response.result.value as! NSDictionary
                self.lessonThreeData.addContent(content: jsonObject.object(forKey: "content") as! String)
                
                
            }
            else {
                self.showAlert(message: "There is an error in retreiving the data.")
            }
        }
        
        Alamofire.request(urlFour).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                // Lesson Four
                let jsonObject = response.result.value as! NSDictionary
                self.lessonFourData.addContent(content: jsonObject.object(forKey: "content") as! String)
                
                
            }
            else {
                self.showAlert(message: "There is an error in retreiving the data.")
            }
        }
        
        
        
        self.dataIndicatorLabel.text = "Data Init Sucess!"
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
    }
    
    
    
    func tryToGetQuestionData() {
        
        let urlOne:String = "https://blindlearningapp.herokuapp.com/get_questions?lesson_name=Math"
        let urlTwo:String = "https://blindlearningapp.herokuapp.com/get_questions?lesson_name=Science"
        let urlThree:String = "https://blindlearningapp.herokuapp.com/get_questions?lesson_name=History"
        let urlFour:String = "https://blindlearningapp.herokuapp.com/get_questions?lesson_name=English"
        
        
        
        Alamofire.request(urlOne).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                let dx = response.result.value as! Dictionary<String, String>
                self.lessonOneData.addQuestion(data: dx)
            }
        }
        
        
        Alamofire.request(urlTwo).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                let dx = response.result.value as! Dictionary<String, String>
                self.lessonTwoData.addQuestion(data: dx)
            }
        }
        
        
        
        Alamofire.request(urlThree).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                let dx = response.result.value as! Dictionary<String, String>
                self.lessonThreeData.addQuestion(data: dx)
            }
        }
        
        
        Alamofire.request(urlFour).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                let dx = response.result.value as! Dictionary<String, String>
                self.lessonFourData.addQuestion(data: dx)
                
            }
        }
        
        
        print ("Question Data saved!")
        
        
        
        
    }
    
    func startAskingQuestions() {
        
        
        
    }
    
    
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            if speechSynthesizer.isSpeaking != true {
                //startAskingQuestions()
                
            }
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lessonOneStack.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonOne)))
        lessonOneStack.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonOneDesc)))
        
        
        lessonTwoStack.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonTwo)))
        lessonTwoStack.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonTwoDesc)))
        
        lessonThreeStack.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonThree)))
        lessonThreeStack.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonThreeDesc)))
        
        lessonFourStack.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonFour)))
        lessonFourStack.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(LessonsViewController.lessonFourDesc)))
        
        
        
        lessonOneData = Lesson(name: "math")
        lessonTwoData = Lesson(name: "science")
        lessonThreeData = Lesson(name: "history")
        lessonFourData = Lesson(name: "english")
        
        
        
        do {
         tryToGetContentDataFromServer()
        tryToGetQuestionData()
        }
        catch  {
            
            print ("error")
            
        
            
        }
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    func speak(what:String) {
        let utterance = AVSpeechUtterance(string:what)
        speechSynthesizer.speak(utterance)
    }
    
    // MARK : TOUCH EVENTS
    
    func lessonOne() {
        speak(what: lessonOneData.content)
        
        for (key,value) in lessonOneData.lesson_questions {
            speak(what: QuestionPattern.First.rawValue)
            speak(what: key)
        }
    }
    
    func lessonTwo() {
        speak(what: lessonTwoData.content)
        
        
    }
    
    func lessonThree() {
        speak(what: lessonThreeData.content)
        
        
    }
    
    func lessonFour() {
        speak(what: lessonFourData.content)
        
        
    }
    
    // MARK: LONG PRESS
    
    func lessonOneDesc() {
        
        showDescriptionForLesson(desc: lessonOneData.content)
        
        
    }
    func lessonTwoDesc() {
        showDescriptionForLesson(desc: lessonTwoData.content)
        
        
    }
    func lessonThreeDesc() {
        showDescriptionForLesson(desc: lessonThreeData.content)
        
        
    }
    func lessonFourDesc() {
        showDescriptionForLesson(desc: lessonFourData.content)
        
        
    }
    
    
}
