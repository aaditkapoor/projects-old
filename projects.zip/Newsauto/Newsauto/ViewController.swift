//
//  ViewController.swift
//  Newsauto
//
//  Created by Aadit Kapoor on 6/14/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import Alamofire
import SwiftSpinner


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let phone_number_url = "https://news-sms-client.herokuapp.com/get-numbers"
    var phoneNumbers:Array<String> = []
    
    var customer1:Creator!
    var customer2:Creator!
    var customer3:Creator!
    
    var requestURLS:Array<String>? = nil
    
    var timer:Timer!

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tableView.delegate = self
        tableView.dataSource = self
        
        
        makeRequest()
        
        // Registering class
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")

        
    }
    
    
    
    func makeRequest() {
        
        Alamofire.request(phone_number_url).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                // Lesson One
                let jsonObject = response.result.value as! NSDictionary
                let c = jsonObject.object(forKey: "phone") as! Array<String>
                
                for i in c {
                    self.phoneNumbers.append(i)
                }
                self.tableView.reloadData()
                print ("Loading complete")
                SwiftSpinner.hide()
                
                print (self.phoneNumbers)
                
                
            }
            else {
                self.createAlert(message:"There is an error in retreiving the data.")
            }
        }
        
        

    
    }
    
    override func viewDidAppear(_ animated: Bool) {
        SwiftSpinner.show("Loading Data")
       

        
    }
    
    func createAlert(message:String) {
        let alert = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        let okay = UIAlertAction(title: "Nice", style: .default, handler: nil)
        alert.addAction(okay)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func startRequest(url:String) {
        Alamofire.request(url).responseData { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                if response.response?.statusCode == 200 {
                    
                    SwiftSpinner.hide()
                    self.createAlert(message: "Success!")
                }
                else {
                    self.createAlert(message: "Error!")
                }
                
            }
            else {
                self.createAlert(message:"There is an error in retreiving the data.")
            }
        }
        

        
    }
    
    func getRequestUrls(url:String) {
        Alamofire.request(url).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                if response.response?.statusCode == 200 {
                    if response.result.value != nil {
                        
                        // Lesson One
                        let jsonObject = response.result.value as! NSDictionary
                        let c = jsonObject.object(forKey: "data") as! Array<String>
                        
                        for i in c {
                           self.startRequest(url: i)
                        }
                        
                        print ("Loading complete")
                    }

                }
                else {
                    self.createAlert(message: "Error!")
                }
                
            }
            else {
                self.createAlert(message:"There is an error in retreiving the data.")
            }
        }
        
    }
    
    
    
    @IBAction func sendMarketingText(_ sender: Any) {
        let url = Command.marketing.rawValue
        SwiftSpinner.show("Sending Marketing request")
        startRequest(url: url)

    }
    
    func createRequestUrlAlert(message:String) {
        var m = message
        let alert = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        let okay = UIAlertAction(title: "Nice", style: .default, handler: {action in
            self.startRequest(url: message)
            })
        alert.addAction(okay)
        self.present(alert, animated: true, completion: nil)

        
    }
    

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let t = tableView.cellForRow(at: indexPath) as! UITableViewCell
        
        // Custom Message here
        
        var phone:String!
        
        if t.textLabel?.text == "AaditKapoor" {
             phone = "9650137978"
        }
        else {
        phone = t.textLabel?.text
        }
        let url = "https://news-sms-client.herokuapp.com/fetch-url-from-phone?phone=\(phone!)"
        
        SwiftSpinner.show("Sending \(phone!) news request")
        
        Alamofire.request(url).responseJSON { response in
            debugPrint(response)
            
            if response.result.value != nil {
                
                if response.response?.statusCode == 200 {
                    if response.result.value != nil {
                        
                        // Lesson One
                        let jsonObject = response.result.value as! NSDictionary
                        let c = jsonObject.object(forKey: "url") as! String
                        
                        print (c)
                        self.createRequestUrlAlert(message: "\(c)")
                        
                        print ("Loading complete")
                        SwiftSpinner.hide()
                    }
                    
                }
                else {
                    self.createAlert(message: "Error!")
                }
                
            }
            else {
                self.createAlert(message:"There was an error in retreiving the data.")
            }
        }

        
        
        
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return phoneNumbers.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! UITableViewCell
        if phoneNumbers[indexPath.row] == "9650137978" {
            cell.textLabel?.text = "AaditKapoor"
        }
        else {
        cell.textLabel?.text = phoneNumbers[indexPath.row]
        }
        
        return cell

    }
    
    // mainFunction
    
    func initializeData() {
        
        // Need to put customers here
        customer1 = Creator.init(phone: "9650137978", type: Command.tech_news.rawValue)
        customer2 = Creator.init(phone: "9582880403",type: Command.general_news.rawValue)
        customer3 = Creator.init(phone: "9910044050", type: Command.indian_news.rawValue)
    
    }
    
    // This process is automatic.
    @IBAction func sendNews(_ sender: Any) {
        
        let url = "https://news-sms-client.herokuapp.com/make-request"
        
        SwiftSpinner.show("Sending News Request")
        getRequestUrls(url: url)
        
        
        
    }

    @IBAction func sendPaymentReminder(_ sender: Any) {
        
        let url = Command.payment.rawValue
        SwiftSpinner.show("Sending Payment request")
        startRequest(url: url)
    }
}

