//
//  URLCreator.swift
//  Newsauto
//
//  Created by Aadit Kapoor on 6/14/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import Foundation


enum Command:String {
    case tech_news = "https://news-sms-client.herokuapp.com/send-tech-news?"
    case sports_news = "https://news-sms-client.herokuapp.com/send-sports-news?"
    case biz_news = "https://news-sms-client.herokuapp.com/send-biz-news?"
    case world_news = "https://news-sms-client.herokuapp.com/send-world-news?"
    case general_news = "https://news-sms-client.herokuapp.com/send-general-news?"
    case payment = "https://news-sms-client.herokuapp.com/send-payment-reminder?"
    case marketing = "https://news-sms-client.herokuapp.com/send-marketing?"
    case indian_news = "https://news-sms-client.herokuapp.com/send-indian-news?"
    case fetch_url = "https://news-sms-client.herokuapp.com/fetch-url-from-phone?"
}

class Creator {
    var url:String!
    
    init(phone:String,type:String) {
        self.url = type + "phone=\(phone)"
    }
    
    func get_url() -> String {
        return self.url
    }
}
