from django.contrib import admin
from .models import LessonModel, QuestionModelFromLesson


admin.site.register(LessonModel)
admin.site.register(QuestionModelFromLesson)