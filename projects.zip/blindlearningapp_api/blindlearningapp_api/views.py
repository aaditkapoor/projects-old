import simplejson as json
from .models import LessonModel, QuestionModelFromLesson
from django.http import HttpResponse

def get_content(request):
	if request.GET.get('lesson_name',''):
		data = LessonModel.objects.get(lesson_name = request.GET.get('lesson_name',''))
		if data:
			return HttpResponse(list(json.dumps({'content':data.lesson_content}, sort_keys=True, indent=4 * ' ')),content_type="application/json")
		else:
			return HttpResponse("ERROR 01: NO CONTENT ADDED!")
	else:
		return HttpResponse("ERROR 02: LESSON NAME NOT PROVIDED!")


def get_questions(request):
	lesson_name = request.GET.get('lesson_name','')

	if lesson_name:
		try:
			lesson_object = LessonModel.objects.get(lesson_name=lesson_name)
			questions = QuestionModelFromLesson.objects.filter(which_lesson=lesson_object)
			data = {}
			j=1
			for i in questions:
				data[i.question] = i.answer
			print questions
			return HttpResponse(list(json.dumps(data, sort_keys=True, indent=4 * ' ')), content_type="application/json")

		except:
			return HttpResponse("ERROR")


	else:
		return HttpResponse("ERROR: NO NAME PROVIDED!")