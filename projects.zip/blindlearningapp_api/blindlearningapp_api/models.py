from django.db import models


class LessonModel(models.Model):

	choices = [('1','Single Question'),('2','Two Questions'),('3','Three Questions'),('4','Four Questions')]

	lesson_name = models.CharField(max_length=500)
	lesson_content = models.CharField(max_length=1000)
	lesson_question_count = models.CharField(max_length=1,choices=choices)

	def __unicode__(self):
		return self.lesson_name



class QuestionModelFromLesson(models.Model):
	which_lesson = models.ForeignKey(LessonModel)
	question = models.CharField(max_length=500)
	answer = models.CharField(max_length=500)


	def __unicode__(self):
		return self.which_lesson.lesson_name
