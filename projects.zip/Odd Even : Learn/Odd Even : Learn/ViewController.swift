//
//  ViewController.swift
//  Odd Even : Learn
//
//  Created by Aadit Kapoor on 4/30/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func showAbout(_ sender: Any) {
        self.performSegue(withIdentifier: "about", sender: self)
        
    }
    
    

    @IBAction func playButton(_ sender: Any) {
        self.performSegue(withIdentifier: "gameplay", sender: self)
    }
}

