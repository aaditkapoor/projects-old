//
//  PlayViewController.swift
//  Odd Even : Learn
//
//  Created by Aadit Kapoor on 5/1/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit

class PlayViewController: UIViewController {
    

        
   
    @IBOutlet weak var button1: UIButton!

    @IBOutlet weak var button2: UIButton!
    
    
    
    
    public func setTextToButton() {
        
        var n: Int = Int(arc4random_uniform(1)+45)
        var n2: Int = Int(arc4random_uniform(1)+45)

        
        if (n == n2) {
            n = n + 10
        }
        
        button1.setTitle(String(n), for: UIControlState.normal)
        button2.setTitle(String(n2), for: UIControlState.normal)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setTextToButton()
    }
    
    
    @IBAction func buttonAction(_ sender: UIButton) {
        
        if (Int(sender.currentTitle!)! % 2 == 0) {
            let alert = UIAlertController(title: "alert", message: "You choose even!", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "okay", style:
                UIAlertActionStyle.default, handler: {action  in
                    
                    print("Hello")
                    
            }))
            
            
            
        }
            
        else {
            let alert = UIAlertController(title: "alert", message: "You choose odd!", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "okay", style:
                UIAlertActionStyle.default, handler: {action  in
                    
                    print("Hello")
                    
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
        

        
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        setTextToButton()
    }
    
    
    
    @IBAction func buttonAction2(_ sender: UIButton) {
        
        if (Int(sender.currentTitle!)! % 2 == 0) {
            let alert = UIAlertController(title: "alert", message: "You choose even!", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "okay", style:
        UIAlertActionStyle.default, handler: {action  in
                
                print("Hello")
                
                }))
        
        
        
        }
        
        else {
            let alert = UIAlertController(title: "alert", message: "You choose odd!", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "okay", style:
                UIAlertActionStyle.default, handler: {action  in
                    
                    print("Hello")
                    
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
        
        
    }
    
    
    
    @IBAction func getText(_ sender: UITextField) {
        let alert = UIAlertController(title: "alert", message:sender.text!, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "okay", style:
            UIAlertActionStyle.default, handler: {action  in
                
             
        }));
            self.present(alert, animated: true, completion: nil)
}
}

    

