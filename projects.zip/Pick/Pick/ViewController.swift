//
//  ViewController.swift
//  Pick
//
//  Created by Aadit Kapoor on 6/16/17.
//  Copyright © 2017 Aadit Kapoor. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    let motionManager = CMMotionManager()

    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var switchOutlet: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if switchOutlet.isOn {
            statusLabel.text = "You are not allowed to pick up your Device"
        }
        else {
            statusLabel.text = "You are allowed to pick up your Device"
        }
        
        
    }
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        if sender.isOn {
            statusLabel.text = "You are not allowed to pick up your Device."
            startGettingMotion()
        }
        else {
            statusLabel.text = "You are allowed to pick up your Device"
            motionManager.stopAccelerometerUpdates()
            createAlert(message: "Now you can pick the device.")
           
        }

    }
    
    func createAlert(message:String) {
        let alert = UIAlertController(title: "Stopped", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Alright", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func motionCode() {
        motionManager.accelerometerUpdateInterval = 0.01
        motionManager.startAccelerometerUpdates(to: OperationQueue.main) { (data, error) in
            if let z = data?.acceleration.z {
                print(z)
                
            }
            }
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        //self.motionCode()
    }
    
    
    
    func startGettingMotion() {
        if motionManager.isAccelerometerActive || motionManager.isAccelerometerAvailable {
            
            let q = DispatchQueue(label: "hello",qos: .background,target:nil)
            
            
        q.async {
                
                self.motionCode()
                
                
                DispatchQueue.main.async {
                    print ("Finished!")
                }
            }
            
        }
            
            
        }
        
    }
    
    
    
    
    
    


